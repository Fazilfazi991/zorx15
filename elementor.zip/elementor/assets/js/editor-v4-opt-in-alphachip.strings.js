__( 'Elementor V4', 'elementor' );
__( 'Elementor V4', 'elementor' );
__( 'You’ve got powerful new tools with Editor V4. But, keep in mind that this is an early release, so don’t use it on live sites yet.', 'elementor' );
__( 'Learn more', 'elementor' );