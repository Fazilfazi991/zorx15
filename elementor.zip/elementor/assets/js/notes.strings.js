__( 'Notes', 'elementor' );
__( 'Notes', 'elementor' );
__( 'Notes', 'elementor' );
__( 'With Notes, teamwork gets even better. Stay in sync with comments, feedback & more on your website.', 'elementor' );
__( 'Connect & Activate', 'elementor' );
__( 'Upgrade', 'elementor' );