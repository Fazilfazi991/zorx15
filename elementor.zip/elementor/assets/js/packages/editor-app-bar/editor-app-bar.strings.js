__( 'Exit to WordPress', 'elementor' );
__( 'More', 'elementor' );
__( 'Elementor Logo', 'elementor' );
__( 'Integrations', 'elementor' );
__( 'User Preferences', 'elementor' );
__( 'Theme Builder', 'elementor' );
__( 'Structure', 'elementor' );
__( 'Refreshed Top Bar layout!', 'elementor' );
__( 'We’ve fine-tuned the Top Bar to make navigation faster and smoother.', 'elementor' );
__( 'Learn More', 'elementor' );
__( 'Got it', 'elementor' );
__( 'Site Settings', 'elementor' );
__( 'Save Changes', 'elementor' );
__( 'Switch Device', 'elementor' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (%dpx and up)', 'elementor' );
// translators: %s: Breakpoint label, %d: Breakpoint size.
__( '%s (up to %dpx)', 'elementor' );
__( 'Keyboard Shortcuts', 'elementor' );
__( 'History', 'elementor' );
__( 'Help Center', 'elementor' );
__( 'Finder', 'elementor' );
__( 'Elements', 'elementor' );
__( 'Widgets', 'elementor' );
__( 'Add Element', 'elementor' );
/* translators: %s: Post type label. */
__( '%s Settings', 'elementor' );
__( 'Document Settings', 'elementor' );
__( 'View Page', 'elementor' );
__( 'Save as Template', 'elementor' );
__( 'Save Draft', 'elementor' );
__( 'Copy and Share', 'elementor' );
__( 'Save Options', 'elementor' );
__( 'Save Options', 'elementor' );
__( 'Publish', 'elementor' );
__( 'Submit', 'elementor' );
__( 'Preview Changes', 'elementor' );
__( 'My Elementor', 'elementor' );
__( 'Connect my account', 'elementor' );