__( 'Interactions', 'elementor' );
__(
					"You've reached the limit of 5 interactions for this element. Please remove an interaction before creating a new one.",
					'elementor'
				);
__( 'Interactions', 'elementor' );
__( 'Play interaction', 'elementor' );
__( 'Duration', 'elementor' );
__( 'Delay', 'elementor' );
__( 'Animate elements with Interactions', 'elementor' );
__(
					'Add entrance animations and effects triggered by user interactions such as page load or scroll.',
					'elementor'
				);
__( 'Create an interaction', 'elementor' );
__( 'Page load', 'elementor' );
__( 'Scroll into view', 'elementor' );
__( 'Trigger', 'elementor' );
// translators: %s: time in milliseconds
__( '%s MS', 'elementor' );
__( 'Fade', 'elementor' );
__( 'Slide', 'elementor' );
__( 'Scale', 'elementor' );
__( 'Effect', 'elementor' );
__( 'In', 'elementor' );
__( 'In', 'elementor' );
__( 'Out', 'elementor' );
__( 'Out', 'elementor' );
__( 'Type', 'elementor' );
__( 'From top', 'elementor' );
__( 'To top', 'elementor' );
__( 'From bottom', 'elementor' );
__( 'To bottom', 'elementor' );
__( 'From left', 'elementor' );
__( 'To left', 'elementor' );
__( 'From right', 'elementor' );
__( 'To right', 'elementor' );
__( 'Direction', 'elementor' );