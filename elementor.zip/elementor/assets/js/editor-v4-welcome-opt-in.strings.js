__( 'Say hello to a new experience!', 'elementor' );
__( 'You\'re now using Editor V4, a new generation of web creation.', 'elementor' );
__( 'Try out Editor V4 elements such as Div, SVG and Paragraph.', 'elementor' );
__( 'Set up a new Class and apply it site-wide for perfect consistency.', 'elementor' );
__( 'Customize any style element per screen size by switching between responsive views.', 'elementor' );
__( 'Need help getting started?', 'elementor' );
__( 'Learn more', 'elementor' );
__( 'Let\'s Go', 'elementor' );