__( 'Name your page', 'elementor' );
__( 'To proceed, please name your first page,', 'elementor' );
__( 'or rename it later.', 'elementor' );
__( 'New Page', 'elementor' );
__( 'Cancel', 'elementor' );
__( 'Save', 'elementor' );