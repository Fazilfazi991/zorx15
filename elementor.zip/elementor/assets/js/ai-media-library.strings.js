__( 'Generate with Elementor AI', 'elementor' );
__( 'Edit with Elementor AI', 'elementor' );
__( 'Edit with Elementor AI', 'elementor' );