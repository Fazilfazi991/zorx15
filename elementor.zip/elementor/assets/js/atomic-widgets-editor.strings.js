__( 'Save as a template', 'elementor' );
__( 'New', 'elementor' );
__( 'Save as a component', 'elementor' );
__( 'New', 'elementor' );
__( 'Add %s', 'elementor' );
__( 'Edit %s', 'elementor' );
__( 'Duplicate %s', 'elementor' );
__( 'Delete %s', 'elementor' );